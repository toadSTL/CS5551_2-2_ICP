var app = angular.module('myApp', []);

app.controller('PersonController', function ($scope) {
   
});
